--[[
  * Copyright (C) 2026 hedv948-source, All Rights Reserved
  * GMOD 9-12 like Server creation
--]]
include( "sgui/cl_init.lua" );
local concommand = require( "concommand" );

local FCVAR_CLIENTDLL = _E.FCVAR_CLIENTDLL or 8

local Warning = dbg.Warning
local DevMsg = dbg.DevMsg
local DevWarning = dbg.DevWarning


_G.__LIST_GAMEMODE = 
{
	"deathmatch",
	"sandbox",
	"campaign",
	"melon_drive"
}

local function loadMap(map)
	if _SERVER then
		engine.ServerCommand("map" .. " " .. tostring(map) .. "\n")
    else
        engine.ClientCmd_Unrestricted("map" .. " " .. tostring(map) .. "\n")
    end
end

local function openServer()
	local PROPERTY = vgui.SGUI.Create( "SPropertyDialog" );
	PROPERTY:SetPos( 10, 10 );
	PROPERTY:SetSize( 470, 500 );
	PROPERTY:SetTitle( "Create Game" );
	PROPERTY:SetVisible( true );
	PROPERTY:SetDraggable( true );
	PROPERTY:SetOKButtonVisible( true );
	PROPERTY:SetOKButtonText( "Create" );

	PROPERTY:MakePopup();

	local tLayout = 
	{
			{ 
				control = "MapSelector", 
				label = "Construct", 
				map = "gm_construct", 
				placement = "left" 
			},
			{ 
				control = "MapSelector", 
				label = "Flatgrass", 
				map = "gm_flatgrass", 
				placement = "right" 
			},
			{ 
				control = "MapSelector", 
				label = "Bigcity", 
				map = "gm_bigcity", 
				placement = "left" 

			},
			{ 
				control = "MapSelector", 
				label = "Construct9", 
				map = "gm_construct_9", 
				placement = "right" 
			},
			{
				--control ="jdjdjx",
		    }
	}
	local tSelectedMap = {}

	local defCX, defCY = 0, 0

	local cX = defCX
	local cY = defCY

	local states = {}
	local spacing = 35
	local cspacingY = 200
	local cspacingX = 50
	local startY = 60
	local leftX = 10
	local rightX = 225
	local leftY = startY
	local rightY = startY

	for k, v in ipairs( tLayout ) do

		if v.placement == "left" then
			x = leftX 
			y = leftY
			leftY = leftY + spacing
		elseif v.placement == "right" then
			x = rightX
			y = rightY
			rightY = rightY + spacing
		end

		if v.control == "MapSelector" then
			local def = vgui.SGUI.Create( "SButton", PROPERTY, tostring( ( v.map or "map" ) ), PROPERTY )
			def:SetPos( x, y )
			def:SetSize(200, 30)
			DevMsg(string.format("Setting Button Position (%s), X: %d , Y: %d\n", v.label, x, y))
			states[v.map] = false
		else
		    if v.control ~= nil then
			  error(string.format("\"%s\" is not defined", tostring( v.control ) ) );
			end
		end
	end


	PROPERTY.OnCommand = function( self, cmd )
	    --if not tSelectedMap[1] then return end
	    if cmd == "gm_construct" then
			tSelectedMap[1] = "gm_construct"
			DevMsg(string.format("Selected map: %s\n", tSelectedMap[1]))
		elseif cmd == "gm_flatgrass" then
			tSelectedMap[1] = "gm_flatgrass"
			DevMsg(string.format("Selected map: %s\n", tSelectedMap[1]))
		elseif cmd == "gm_bigcity" then
			tSelectedMap[1] = "gm_bigcity"
			DevMsg(string.format("Selected map: %s\n", tSelectedMap[1]))
		elseif cmd == "gm_construct_9" then
			tSelectedMap[1] = "gm_construct_9"
			DevMsg(string.format("Selected map: %s\n", tSelectedMap[1]))
		end
		--tSelectedMap[1] = tostring( cmd )
	end

	PROPERTY.OnOK = function( self, apply )
		if not tSelectedMap[1] or tSelectedMap[1] == nil then 
			Warning("You must choose a map\n")
		else
			loadMap(tSelectedMap[1])
		end
	end
end	

concommand.Create( "OpenCreateSingleplayer", openServer, "", FCVAR_CLIENTDLL )