--[[
  *
  * Copyright (C) 2026 hedv948-source, All Rights Reserved.
  *
--]]

local MapPatterns = {}

MapPatterns[ "^de_" ] = "Counter-Strike"
MapPatterns[ "^cs_" ] = "Counter-Strike"
MapPatterns[ "^es_" ] = "Counter-Strike"

MapPatterns[ "^cp_" ] = "Team Fortress 2"
MapPatterns[ "^ctf_" ] = "Team Fortress 2"
MapPatterns[ "^tc_" ] = "Team Fortress 2"
MapPatterns[ "^pl_" ] = "Team Fortress 2"
MapPatterns[ "^arena_" ] = "Team Fortress 2"
MapPatterns[ "^koth_" ] = "Team Fortress 2"
MapPatterns[ "^tr_" ] = "Team Fortress 2"

MapPatterns[ "^dod_" ] = "Day Of Defeat"

MapPatterns[ "^d1_" ] = "Half-Life 2"
MapPatterns[ "^d2_" ] = "Half-Life 2"
MapPatterns[ "^d3_" ] = "Half-Life 2"
MapPatterns[ "credits" ] = "Half-Life 2"

MapPatterns[ "^ep1_" ] = "Half-Life 2: Episode 1"
MapPatterns[ "^ep2_" ] = "Half-Life 2: Episode 2"
MapPatterns[ "^ep3_" ] = "Half-Life 2: Episode 3"

MapPatterns[ "^escape_" ] = "Portal"
MapPatterns[ "^testchmb_" ] = "Portal"

MapPatterns[ "^sp_" ] = "Portal 2"
MapPatterns[ "^mp_coop" ] = "Portal 2"

MapPatterns[ "^gm_" ] = "Garry's Mod"
MapPatterns[ "^hl2sb_" ] = "Half-Life 2 Sandbox"

MapPatterns[ "^c0a" ] = "Half-Life: Source"
MapPatterns[ "^c1a" ] = "Half-Life: Source"
MapPatterns[ "^c2a" ] = "Half-Life: Source"
MapPatterns[ "^c3a" ] = "Half-Life: Source"
MapPatterns[ "^c4a" ] = "Half-Life: Source"
MapPatterns[ "^c5a" ] = "Half-Life: Source"
MapPatterns[ "^t0a" ] = "Half-Life: Source"

MapPatterns[ "boot_camp" ] = "Half-Life: Source Deathmatch"
MapPatterns[ "bounce" ] = "Half-Life: Source Deathmatch"
MapPatterns[ "crossfire" ] = "Half-Life: Source Deathmatch"
MapPatterns[ "datacore" ] = "Half-Life: Source Deathmatch"
MapPatterns[ "frenzy" ] = "Half-Life: Source Deathmatch"
MapPatterns[ "rapidcore" ] = "Half-Life: Source Deathmatch"
MapPatterns[ "stalkyard" ] = "Half-Life: Source Deathmatch"
MapPatterns[ "snarkpit" ] = "Half-Life: Source Deathmatch"
MapPatterns[ "subtransit" ] = "Half-Life: Source Deathmatch"
MapPatterns[ "undertow" ] = "Half-Life: Source Deathmatch"
MapPatterns[ "lambda_bunker" ] = "Half-Life: Source Deathmatch"

MapPatterns[ "dm_" ] = "Half-Life 2 Deathmatch"

local IgnorePatterns = {
	"^background",
	"^devtest",
	"^ep1_background",
	"^ep2_background",
	"^styleguide",
}

local IgnoreMaps = {
	-- Prefixes
	[ "sdk_" ] = true,
	[ "test_" ] = true,
	[ "vst_" ] = true,

	-- Maps
	[ "c4a1y" ] = true,
	[ "credits" ] = true,
	[ "d2_coast_02" ] = true,
	[ "d3_c17_02_camera" ] = true,
	[ "ep1_citadel_00_demo" ] = true,
	[ "c5m1_waterfront_sndscape" ] = true,
	[ "intro" ] = true,
	[ "test" ] = true
}