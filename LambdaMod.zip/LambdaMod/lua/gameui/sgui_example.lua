--[[ 
   * Copyright (C) 2026 hedv948-source, All Rights Reserved
   * Purpose: Example for SGUI Library 
--]]

include( "sgui/cl_init.lua" )
--include( "palm/cl_init.lua" )

local concommand = require( "concommand" )
local FCVAR_CLIENTDLL = _E.FCVAR.CLIENTDLL or 8

local function examplePanel()
  local FRAME = vgui.SGUI.Create( "SFrame" );
  
  FRAME:SetPos( 5, 5 );
  FRAME:SetSize( 300, 150 );
  FRAME:SetTitle("Window - SGUI")
  FRAME:SetVisible(true)
  FRAME:SetDraggable(false) 
  FRAME:ShowCloseButton(true) 
  
  FRAME:MakePopup()
end

concommand.Create( "OpenSGUIPanel", examplePanel, "", FCVAR_CLIENTDLL)

local function exampleProperty()
  local _PROPERTY = vgui.SGUI.Create( "SPropertyDialog" )
  _PROPERTY:SetPos( 5, 5 );
  _PROPERTY:SetSize( 300, 550 );
  _PROPERTY:SetTitle("Create Singleplayer game")
  _PROPERTY:SetVisible(true)
  _PROPERTY:SetDraggable(false) 
  _PROPERTY:SetOKButtonVisible( true )
  --_PROPERTY:SetOKButtonText( "Create" )
  
  _PROPERTY:MakePopup()
  
  --local PAGE = vgui.SGUI.Create( "SPropertyPage",  PROPERTY )
  --PAGE:SetPos(0, 0) -- x,y
  --PAGE:SetSize(300, 150) -- width, height
  --PAGE:SetVisible(true)
  local pX = 100
  local _BUTTON_1 = vgui.SGUI.Create( "SButton", _PROPERTY, "button", _PROPERTY, "_b1" )
  _BUTTON_1:SetPos( pX, 40 )
  _BUTTON_1:SetSize( 40, 12 )
  _BUTTON_1:SetVisible( true )
  
  local _BUTTON_2 = vgui.SGUI.Create( "SButton", _PROPERTY, "Button 2", _BUTTON2, "cmd" )
  _BUTTON_2:SetPos( pX, 60 )
  _BUTTON_2:SetSize( 40, 12 )
  _BUTTON_2:SetVisible( true )
  
  _BUTTON_2.DoClick = function()
    dbg.Msg("Using DoClick()\n")
  end
  local _CHECKBOX_1 = vgui.SGUI.Create( "SCheckButton", _PROPERTY, "Example checkbox" )
  _CHECKBOX_1:SetPos( pX, 80 )
  _CHECKBOX_1:SetVisible( true )
  _CHECKBOX_1.OnCheckButtonChecked = function(self)
    dbg.Msg("Check button checked\n")
  end
  
  --_PROPERTY:AddPage( PAGE, "Example" )
  _PROPERTY.OnCommand = function( self, cmd )
    if cmd == "_b1" then
      dbg.Msg( "button clicked\n" )
     end
  end
  
  _PROPERTY.OnOK = function( self, applyOnly )
    dbg.Msg("OK Clicked\n");
  end
  
end

concommand.Create( "OpenSGUIProperty", exampleProperty, "", FCVAR_CLIENTDLL )