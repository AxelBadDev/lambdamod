local concommand = require( "concommand" )

local FCVAR_CLIENTDLL = _E.FCVAR.CLIENTDLL or 8

concommand.Create( "lua_dostring_gameui", function( ply, cmd, arg )
  if not arg then dbg.Msg("Usage: lua_dostring_gameui <string>\n") return end
  
  local fn, err = loadstring(arg)
  if not fn then
    dbg.Warning("[Lua Compile Error]: " .. tostring( err ) .. "\n" )
    return
  end
  
  local run, runErr = pcall( fn )
  
  if not run then 
    dbg.Warning("[Lua Runtime Error]: " .. tostring( runErr ) .. "\n" )
    return
  end
  
end, "Runs Lua code", FCVAR_CLIENTDLL )