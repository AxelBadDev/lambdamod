--[[ 
   *
   * Copyright (C) 2026 hedv948-source, All Rights Reserved
   *
   * Purpose: Initialize LambdaMod
   *
   *
]]

if CLIENT or _CLIENT then return end -- Make sure its server-side only



local function includeCore( pFile )
	include( "core/" .. pFile )
end

local function includelib( pFile )
	includeCore( "includes/" .. pFile  )
end

include( "core/core.lua" )
include( "core/shared.lua" )
include( "core/includes/lambdamod.lua" )
include( "core/includes/cvar.lua" )
include( "core/includes/libadmin.lua" )
include( "core/includes/vscript.lua" )

include( "config/admins.lua" )