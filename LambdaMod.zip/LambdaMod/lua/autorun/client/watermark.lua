require("spaint")

surface = surface

if not spaint.CreateFont then
  local function register_font(name, data)
    local hFont = surface.CreateFont()
    local fontObj = pFont:new(name, hFont)

    fontObj:setupData(data)
    fontObj:setupFlags(data)
    fontObj:register()

    tFontHandle[string.lower(name)] = fontObj
  end

  local function getFont(name)
    return tFontHandle[string.lower(name)]
  end

  function spaint.CreateFont(name, data)
    if type(name) ~= "string" then
        error("spaint.CreateFont: expected string (1)", 2)
    end

    if type(data) ~= "table" then
        error("spaint.CreateFont: expected table (2)", 2)
    end

    register_font(name, data)
  end
end

spaint.CreateFont("TestFont", {
    font = "Verdana",
    size = 29,
    weight = 1000,
    antialias = false,
    shadow = false
})

hook.add("HudElementShouldDraw", "TestSPaint", function( pElementName )
	--dbg.DevMsg( tostring( pElementName ) .. "\n" );
	--if ( pElementName == "CHudWatermark" ) then
    spaint.Text(
	{
        text = "LambdaMod v2.0",
        pos = {15, 5},
        font = "TestFont",
        color = Color(0,255,0)
    }, 2 )
    --end

end)