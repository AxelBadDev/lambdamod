local cvar = require( "cvar" )
SLib = SLib or {}
local FCVAR_CLIENTDLL = FCVAR_CLIENTDLL or _E.FCVAR.CLIENTDLL

local slib_debug = ConVar( "slib_debug", "0", FCVAR_CLIENTDLL, "Enable Debugging for SLib")

cvar.AddChangeCallback("slib_debug", "slib_debug", function(cvar, old, v)
    SLib.DebugEnabled = cvar:GetBool()
	if _CLIENT then
		if cvar:GetBool() then
			dbg.Msg("Debugging is Enabled\n")
		else
			dbg.Msg("Debugging is Disabled\n")
		end
	end
    --gpmb2.SaveConVarValue(cvar:GetName(), cvar:GetString())
end)
