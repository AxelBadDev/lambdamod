--========= Copyright (C) 2026 hedv948-source, All Rights Reserved =========--
--                                                      
-- Purpose:                                             
--                                                      
--==========================================================================--

include("api/sm_shared_cs.lua")
includeC("slib_table.lua")
includeC("slib_cvars.lua")
--local _SOURCEMOD:printfc = _SOURCEMOD:printfc
local concommand = require( "concommand" )

local FCVAR_CLIENTDLL = FCVAR_CLIENTDLL or _E.FCVAR.CLIENTDLL
SLib = SLib or {}

slib = {}
slib.isInitialized = true

SLib.version = _SOURCEMOD.INFO._VERSION

function SLib.Info()
	_SOURCEMOD:printfc(1, "#=========\n")
	_SOURCEMOD:printfc(2, "SLib Version: "); _SOURCEMOD:printfc(5, "%s\n", tostring( SLib.version ) )
	_SOURCEMOD:printfc(0, "Github: hedv948-source\n")

	if SLib.DebugEnabled ~= nil and SLib.DebugEnabled == true then
		_SOURCEMOD:printfc(2, "Debugging is "); _SOURCEMOD:printfc(5, "Enabled\n")
	elseif SLib.DebugEnabled ~= nil and SLib.DebugEnabled == false then
		_SOURCEMOD:printfc(2, "Debugging is "); _SOURCEMOD:printfc(3, "Disabled\n")
	end
end

concommand.Create("slib", SLib.info, "SLib infomation", FCVAR_CLIENTDLL)
