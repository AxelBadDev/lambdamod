--========= Copyright (C) 2026 hedv948-source, All Rights Reserved =========--
--                                                      
-- Purpose: Hedv948's LuaPlus implemention                                          
--                                                      
--==========================================================================--
if _G.__LUAPLUS_LOADED then return end
_G.__LUAPLUS_LOADED = true

