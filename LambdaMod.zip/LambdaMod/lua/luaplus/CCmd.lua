--========= Copyright (C) 2026 hedv948-source, All Rights Reserved =========--
--                                                      
-- Purpose:                                           
--                                                      
--==========================================================================--

CCmd = CCmd or {}
CCmd.Client = {}
CCmd.Server = {}

local Client = CCmd.Client
local Server = CCmd.Server

function Client.Run(cmd)
	engine.ClientCmd( cmd .. "\n" )
end

function Server.Run(cmd)
	if ( _SERVER ) then 
		engine.ServerCommand( cmd .. "\n" )
	else
		engine.ClientCmd_Unrestricted( cmd .. "\n" )
	end
end


return CCmd

