
include( "shared.lua" )

local VIEW_DISTANCE = 500  -- Дальность обзора пропa
local VIEW_ANGLE = 180    -- Угол обзора пропa (в градусах)

function ENT:IsPlayerInView(player)
    local propPos = self:GetPos()
    local playerPos = player:GetPos()
    local directionToPlayer = (playerPos - propPos)
    local propForward = self:GetForward()

    -- Проверяем расстояние до игрока
    local distance = propPos:DistTo(playerPos)
    if distance > VIEW_DISTANCE then
        return false
    end

    -- Проверяем угол между направлением на игрока и направлением взгляда пропa
    local angle = math.acos(propForward:Dot(directionToPlayer))
    angle = math.deg(angle) -- Convert radians to degrees

    if angle <= VIEW_ANGLE / 2 then
        self.IsPlayerDetected = true
    else
        self.IsPlayerDetected = false
    end
end

function ENT:Think(player)
	--Ищем локального игрока. Можно заменить на перебор всех игроков, если нужно чтобы проп видел всех.
    local inView = self:IsPlayerInView(self, player)
	
 	self.IsPlayerDetected = false
    if inView and not self.IsPlayerDetected then
    	-- Игрок вошел в поле зрения
    	print("Я нашёл тебя")
    	self.IsPlayerDetected = true
    elseif not inView and self.IsPlayerDetected then
    	-- Игрок вышел из поля зрения
    	print("Поиск")
   		self.IsPlayerDetected = false
    end
	self:NextThink(gpGlobals:curtime() + 1)
 	return true
end
