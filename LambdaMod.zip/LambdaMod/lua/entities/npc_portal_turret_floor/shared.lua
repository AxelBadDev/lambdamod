ENT.Name = "Portal Turret"
ENT.Type = "CBaseAnimating"


function ENT:Initialize()
   self:SetModel("models/props/turret_01.mdl")
end

