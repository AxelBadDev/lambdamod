local print = print
local engine = engine
local ServerCommand = engine.ServerCommand
local ClientCmd_Unrestricted = engine.ClientCmd_Unrestricted
local dbg = dbg
local tostring = tostring
local pcall = pcall
local setmetatable = setmetatable
local getmetatable = getmetatable
local ipairs = ipairs
local pairs = pairs

module( "sourcemod_console" )
local function tableToSet(tble)
		local set = {}
		for _, v in ipairs(tble) do
				set[v] = true
		end
		return set
end

--===================================--
-- Shared Blacklisted commands table --
--                                   --
--===================================--

local shared_tCmdblacklist = {
		"sv_cheats",
		"exec",
		"lua_dostring",
		"lua_dostring_cl",
		"lua_dofile",
		"lua_dofile_cl",
		"developer",
		"ent_fire",
		--"echo",
		"fps_max",
		"quit",
		"sv_password",
		"name",
		"connect",
		"buildcubemaps",
		"bind",
		"unbind",
		"unbindall"
}

local bCmd = tableToSet(shared_tCmdblacklist)

function RunConsoleCommand(cmd, ...)
	if bCmd[cmd] then
		dbg.Warning(string.format("RunConsoleCommand: Command is blocked! (%s)\n", tostring( cmd ) ) )
		return
	end
	if _SERVER then
		engine.ServerCommand(cmd .. " " .. tostring(...) )
	elseif _CLIENT then
		engine.ClientCmd_Unrestricted( cmd .. " " .. tostring(...) )
	end
end
