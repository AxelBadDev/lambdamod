libConsole = {}
libConsole.Client = {}
libConsole.ClientU = {}
libConsole.Server = {}

local ConClient = libConsole.Client
local ConClientU = libConsole.ClientU
local ConServer = libConsole.Server

function ConClient.Run(command)
	if CLIENT then
	    engine.ClientCmd(command)
	end
end

function ConClientU.Run(cmd)
	engine.ClientCmd_Unrestricted(cmd)
end

--- Sends a chat message.
---@param text string
function ConClient.Say(text)
    ConClient.Run("say " .. text)
end

--- Sends a team chat message.
---@param text string
function ConClient.SayTeam(text)
    ConClient.Run("say_team " .. text)
end

--- Enables sv_cheats.
function ConClient.EnableCheats()
    ConClient.Run("sv_cheats 1")
end

--- Disables sv_cheats.
function ConClient.DisableCheats()
    ConClient.Run("sv_cheats 0")
end

--- Toggles noclip.
function ConClient.NoClip()
    ConClient.Run("noclip")
end

--- Toggles god mode.
function ConClient.God()
    ConClient.Run("god")
end

--- Toggles buddha mode.
function ConClient.Buddha()
    ConClient.Run("buddha")
end

--- Toggles notarget.
function ConClient.Notarget()
    ConClient.Run("notarget")
end

--- Kills the player.
function ConClient.Kill()
    ConClient.Run("kill")
end

--- Respawns the player.
function ConClient.Respawn()
    ConClient.Run("respawn")
end

--- Sets player field of view.
---@param fov number
function ConClient.SetFOV(fov)
    ConClient.Run("fov " .. tostring(fov))
end

--- Switches to first-person view.
function ConClient.FirstPerson()
    ConClient.Run("firstperson")
end

--- Switches to third-person view.
function ConClient.ThirdPerson()
    ConClient.Run("thirdperson")
end

--- Enables or disables the viewmodel.
---@param enable boolean
function ConClient.DrawViewModel(enable)
    ConClient.Run("r_drawviewmodel " .. (enable and "1" or "0"))
end

--- Spawns an NPC.
---@param class string
function ConClient.SpawnNPC(class)
    ConClient.Run("npc_create " .. class)
end

--- Spawns an aimed NPC.
---@param class string
function ConClient.SpawnNPCAim(class)
    ConClient.Run("npc_create_aimed " .. class)
end

--- Spawns a physics prop.
---@param model string
function ConClient.SpawnProp(model)
    ConClient.Run("prop_physics_create " .. model)
end

--- Spawns a dynamic prop.
---@param model string
function ConClient.SpawnDynamicProp(model)
    ConClient.Run("prop_dynamic_create " .. model)
end

--- Spawns a vehicle.
---@param class string
function ConClient.SpawnVehicle(class)
    ConClient.Run("vehicle_create " .. class)
end

--- Gives a weapon to the player.
---@param weapon string
function ConClient.GiveWeapon(weapon)
    ConClient.Run("give " .. weapon)
end

--- Gives all weapons.
function ConClient.GiveAll()
    ConClient.Run("impulse 101")
end

--- Kills all NPCs.
function ConClient.KillAllNPCs()
    ConClient.Run("npc_killall")
end

--- Makes AI ignore the player.
function ConClient.IgnorePlayer()
    ConClient.Run("ai_ignoreplayers 1")
end

--- Restores AI behavior toward the player.
function ConClient.RespectPlayer()
    ConClient.Run("ai_ignoreplayers 0")
end

--- Disables AI.
function ConClient.DisableAI()
    ConClient.Run("ai_disabled 1")
end

--- Enables AI.
function ConClient.EnableAI()
    ConClient.Run("ai_disabled 0")
end

--- Reloads the current map.
function ConClient.ReloadMap()
    ConClient.Run("reload")
end

--- Changes the current map.
---@param map string
function ConClient.ChangeMap(map)
    ConClient.Run("changelevel " .. map)
end

--- Clears decals.
function ConClient.CleanDecals()
    ConClient.Run("r_cleardecals")
end

--- Shows FPS counter.
function ConClient.ShowFPS()
    ConClient.Run("cl_showfps 1")
end

--- Hides FPS counter.
function ConClient.HideFPS()
    ConClient.Run("cl_showfps 0")
end

--- Enables or disables wireframe rendering.
---@param enable boolean
function ConClient.Wireframe(enable)
    ConClient.Run("mat_wireframe " .. (enable and "1" or "0"))
end

--- Enables or disables fullbright.
---@param enable boolean
function ConClient.FullBright(enable)
    ConClient.Run("mat_fullbright " .. (enable and "1" or "0"))
end

--- Binds a key to a command.
---@param key string
---@param command string
function ConClient.Bind(key, command)
    ConClient.Run("bind " .. key .. " " .. command)
end

--- Unbinds a key.
---@param key string
function ConClient.Unbind(key)
    ConClient.Run("unbind " .. key)
end

--- Unbinds all keys.
function ConClient.UnbindAll()
    ConClient.Run("unbindall")
end

--- Executes a config file.
---@param cfg string
function ConClient.Exec(cfg)
    ConClient.Run("exec " .. cfg)
end

--- Writes the current config.
function ConClient.WriteConfig()
    ConClient.Run("host_writeconfig")
end

--- Sets game volume.
---@param volume number
function ConClient.SetVolume(volume)
    ConClient.Run("volume " .. tostring(volume))
end

--- Mutes the game.
function ConClient.Mute()
    ConClient.Run("volume 0")
end

--- Sets a console variable.
---@param cvar string
---@param value string|number
function ConClient.SetCVar(cvar, value)
    ConClient.Run(cvar .. " " .. tostring(value))
end

--- Runs a raw console command (alias).
---@param command string
function ConClient.Raw(command)
    ConClient.Run(command)
end

--SCmd = {}

--- Runs a raw server command.
---@param command string
function ConServer.Run(command)
	if _SERVER or SERVER then
	    engine.ServerCommand(command)
	else
		engine.ClientCmd_Unrestricted(command)
	end
end

--- Sets a server cvar.
---@param cvar string
---@param value string|number
function ConServer.SetCVar(cvar, value)
    ConServer.Run(cvar .. " " .. tostring(value))
end

--- Changes the current map on the server.
---@param map string
function ConServer.ChangeMap(map)
    ConServer.Run("changelevel " .. map)
end

--- Kicks a player by name or userid.
---@param target string
---@param reason? string
function ConServer.Kick(target, reason)
    if reason then
        ConServer.Run("kick " .. target .. " " .. reason)
    else
        ConServer.Run("kick " .. target)
    end
end

--- Bans a player by name or userid.
---@param target string
---@param minutes number
function ConServer.Ban(target, minutes)
    ConServer.Run("banid " .. tostring(minutes) .. " " .. target)
end

--- Executes a server config file.
---@param cfg string
function ConServer.Exec(cfg)
    ConServer.Run("exec " .. cfg)
end

--- Reloads the current map.
function ConServer.ReloadMap()
    ConServer.Run("reload")
end

--- Restarts the current map.
function ConServer.Restart()
    ConServer.Run("map_restart")
end

--- Enables server cheats.
function ConServer.EnableCheats()
    ConServer.Run("sv_cheats 1")
end

--- Disables server cheats.
function ConServer.DisableCheats()
    ConServer.Run("sv_cheats 0")
end

--- Sends a raw server command (alias).
---@param cmd string
function ConServer.Raw(cmd)
    ConServer.Run(cmd)
end

return libConsole