--[[
	* all code made by YourGlobalCappy
]]

module( "libcrypt", package.seeall )

--module( "spaint", package.seeall )

local surface = surface
local bit = bit
local table = table
local string = string
local type = type
local setmetatable = setmetatable
local ipairs = ipairs
local Color = Color

function encrypt(text, key)
    local result = ""
    local klen = #key

    for i = 1, #text do
        local t = string.byte(text, i)
        local k = string.byte(key, ((i - 1) % klen) + 1)

        local encrypted = (t + k) % 256
        result = result .. string.char(encrypted)
    end

    return result
end

function decrypt(text, key)
    local result = ""
    local klen = #key

    for i = 1, #text do
        local t = string.byte(text, i)
        local k = string.byte(key, ((i - 1) % klen) + 1)

        local decrypted = (t - k) % 256
        result = result .. string.char(decrypted)
    end

    return result
end

