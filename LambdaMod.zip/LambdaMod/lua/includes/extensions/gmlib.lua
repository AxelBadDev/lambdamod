function isnumber( x )
	if type( x ) == "number" then 
		return true 
	else 
		return false 
	end
end

function isbool( x )
	if type( x ) == "boolean" then 
		return true 
	else 
		return false 
	end
end

function isstring( x )
	if type( x ) == "string" then 
		return true 
	else 
		return false 
	end
end

function isFunction( x )
	if type( x ) == "function" then 
		return true 
	else 
		return false 
	end
end