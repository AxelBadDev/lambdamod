-- inc.lua
includeC("controls/spanel.lua")
includeC("controls/sframe.lua")
includeC("controls/sbutton.lua")
includeC("controls/slabel.lua")
includeC("controls/scheckbutton.lua")
includeC("controls/spropertydialog.lua")
includeC("controls/spropertypage.lua")
