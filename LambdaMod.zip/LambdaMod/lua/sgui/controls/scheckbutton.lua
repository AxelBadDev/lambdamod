-- pcheckbutton.lua

---@class PCheckButton:CheckButton
---@field Init fun(self:PCheckButton, parent:Panel?, panelName:string, text:string)
local SCheckButton = {
  base = "CheckButton",

  Init = function(self, parent, text)
    self:SetParent(parent)
  end,

  Activate = function(self) end,
}

SCONTROLS.Add("SCheckButton", SCheckButton)
