-- pbutton.lua

---@class PButton:Frame
---@field Init fun(self:PButton, parent:Panel?, text:string, actionSignalTarget:Panel, cmd:string)
local SButton = {
  base = "Button",

  Init = function(self, parent, text, actionSignalTarget, cmd)
    self:SetParent(parent)
  end,

  Activate = function(self) end,
}

SCONTROLS.Add("SButton", SButton)
