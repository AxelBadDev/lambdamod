-- DO NOT MODIFY THIS FILE 
-- USE blocked_concommands.lua INSTEAD
LambdaMod = LambdaMod or {}

local Core = LambdaMod.Core
local AddBlacklistedCvar = Core.AddBlacklistedCvar

local blacklistedCmds = {
		"sv_cheats",
		"exec",
		"lua_dostring",
		"lua_dostring_cl",
		"lua_dofile",
		"lua_dofile_cl",
		"developer",
		"ent_fire",
		"echo",
		"fps_max",
		"quit",
		"sv_password",
		"name",
		"connect",
		"buildcubemaps",
		"bind",
		"unbind",
		"unbindall"
}

for _, v in ipairs( blacklistedCmds ) do 
	Core.AddBlacklistedCvar( v )
end