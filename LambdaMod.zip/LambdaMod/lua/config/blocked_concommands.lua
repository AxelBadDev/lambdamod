-- You can config blacklisted command using AddBlacklistedCvar()
-- Example: AddBlacklistedCvar( "example" )

LambdaMod = LambdaMod or {}

local Core = LambdaMod.Core
local AddBlacklistedCvar = Core.AddBlacklistedCvar

--AddBlacklistedCvar( "" )