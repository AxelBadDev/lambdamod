--[[ 
   * Copyright (C) 2026 hedv948-source, All Rights Reserved
   * Purpose: 
--]]
local LibAdmin = LambdaMod.LibAdmin

function PerformKick( pCaller, pTargets )
	local targets = LibAdmin.ParseTargets( pTargets, pCaller )
	
	if #targets == 0 then
        LambdaMod.printfc(3, "No matching players for \"%s\".\n", tostring(pTargets) )
        return
    end
	for _, v in ipairs( targets ) do
		LambdaMod.printfc( 0, "%s kicked %s\n", pCaller:GetPlayerName(), v:GetPlayerName() ) 
		LambdaMod.Core.ForwardToConsole("kick " .. v:GetPlayerName() )
	end
end